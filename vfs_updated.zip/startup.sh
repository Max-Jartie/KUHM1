ls
cd home/user
cat /home/user/documents/file2.txt
cd /